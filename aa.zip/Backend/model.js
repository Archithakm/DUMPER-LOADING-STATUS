const mongoose = require("mongoose");

const dumperSchema = new mongoose.Schema({
    dumperid: {
        type: String,
        required: true,
    },
    dumpername: {
        type: String,
        required: true,
    },
    status: {
        type: String,
        required: true,
        enum: ['Active', 'Inactive'],
    }
});

const Dumper = mongoose.model("dumperdetails", dumperSchema);

const employeeSchema = new mongoose.Schema({
    EmployeeId: {
        type: String,
        required: true,
    },
    EmployeeName: {
        type: String,
        required: true,
    },
    EmployeeRole: {
        type: String,
        enum: ['Showel Operator', 'Dumper Operator'],
    },
    status: {
        type: String,
        required: true,
        enum: ['Active', 'Inactive'],
    }
});

const Employee = mongoose.model("EmployeeDetails", employeeSchema);

const TripModelSchema = new mongoose.Schema({
    date: {
      type: String,
      required: true,
    },  
    inTime: {
      type: String,
      required: true,
    },
    outTime: {
      type: String,
      required: true,
    },
    dumperID: {
      type: String,
      required: true,
    },
    dumperShovelID: {
      type: String,
      required: true,
    },
    status: {
      type: String,
      enum: ['Active', 'Inactive'],
      required: true,
    },
  });
  
  const TripModel = mongoose.model('TripDetails', TripModelSchema);

  
const shovelSchema = new mongoose.Schema({
    shovelid: {
        type: String,
        required: true,
    },
    shovelname: {
        type: String,
        required: true,
    },
    status: {
        type: String,
        required: true,
        enum: ['Active', 'Inactive'],
    }
});

const shovel = mongoose.model("shoveldetails", shovelSchema);

module.exports = { Dumper, Employee, TripModel, shovel };
