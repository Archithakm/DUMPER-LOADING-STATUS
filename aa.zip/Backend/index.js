const express = require("express");
const app = express();
const mongoose = require("mongoose");
const cors = require("cors");
const { Dumper, Employee, TripModel, shovel } = require('./model.js');


app.use(express.json());
app.use(cors());

const mongoUrl = "mongodb+srv://archithamohanrao:qUfd0tTjBANky9eD@cluster0.pejzotj.mongodb.net/";

mongoose.connect(mongoUrl, {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => {
  console.log("Connected to the database");
}).catch(e => console.log(e));

app.listen(5000, () => {
  console.log("Server started");
});


app.post("/dumpers", async (req, res) => {
  try {
    const newDumper = new Dumper(req.body);
    await newDumper.save();
    res.json(newDumper);
  } catch (error) {
    console.error("Server error:", error);

    if (error.name === 'ValidationError') {
      const validationErrors = Object.values(error.errors).map(err => err.message);
      res.status(400).json({ error: 'Validation Error', details: validationErrors });
    } else {
      res.status(500).json({ error: 'Internal Server Error', details: error.message });
    }
  }
});

//Insert the Data into Employee Details 

app.post("/employee", async (req, res) => {
    try {
      const newDumper = new Employee(req.body);
      await newDumper.save();
      res.json(newDumper);
    } catch (error) {
      console.error("Server error:", error);
  
      if (error.name === 'ValidationError') {
        const validationErrors = Object.values(error.errors).map(err => err.message);
        res.status(400).json({ error: 'Validation Error', details: validationErrors });
      } else {
        res.status(500).json({ error: 'Internal Server Error', details: error.message });
      }
    }
  });


//Insert Data in to Trip Details

  app.post("/trip", async (req, res) => {
    try {

      const newDumper = new TripModel(req.body);
      await newDumper.save();
      res.json(newDumper);
    } catch (error) {
      console.error("Server error:", error);
  
      if (error.name === 'ValidationError') {
        const validationErrors = Object.values(error.errors).map(err => err.message);
        res.status(400).json({ error: 'Validation Error', details: validationErrors });
      } else {
        res.status(500).json({ error: 'Internal Server Error', details: error.message });
      }
    }
  });


//insert shovel data
app.post("/shovel", async (req, res) => {
  try {
    const newDumper = new shovel(req.body);
    await newDumper.save();
    res.json(newDumper);
  } catch (error) {
    console.error("Server error:", error);

    if (error.name === 'ValidationError') {
      const validationErrors = Object.values(error.errors).map(err => err.message);
      res.status(400).json({ error: 'Validation Error', details: validationErrors });
    } else {
      res.status(500).json({ error: 'Internal Server Error', details: error.message });
    }
  }
});



app.get('/get',(req,res)=>{
  Employee.find({}).then((user)=>{
      return res.status(200).json(user);
  })
})


app.get('/getdumper',(req,res)=>{
  Dumper.find({}).then((user)=>{
      return res.status(200).json(user);
  })
})

app.get('/getshovel',(req,res)=>{
  shovel.find({}).then((user)=>{
      return res.status(200).json(user);
  })
})

app.get('/gettrips',(req,res)=>{
  TripModel.find({}).then((user)=>{
      return res.status(200).json(user);
  })
})
